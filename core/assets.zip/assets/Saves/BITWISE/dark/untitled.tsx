<?xml version="1.0" encoding="UTF-8"?>
<tileset name="air" tilewidth="16" tileheight="16" tilecount="400" columns="20">
 <image source="megaminer.png" width="320" height="320"/>
</tileset>
