<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Wall" tilewidth="16" tileheight="16" tilecount="16" columns="4">
 <image source="../../../Sprites/bitWise/6.png" width="64" height="64"/>
 <terraintypes>
  <terrain name="Wall" tile="7"/>
 </terraintypes>
 <tile id="15" terrain="0,0,0,0"/>
</tileset>
