libgdx-particles
================

my particle effect presets

## How to view in editor ##
1. Put your runnable-2D-particles.jar in libgdx-particles folder.
2. Enjoy it.
